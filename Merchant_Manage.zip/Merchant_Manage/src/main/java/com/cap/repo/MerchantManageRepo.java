package com.cap.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.MerchantManage;

@Repository
public interface MerchantManageRepo extends JpaRepository<MerchantManage, Integer> {
	
	
	@Query(value="select * from capstore_merchants where merchant_status like 'active'",nativeQuery = true)
	public List<MerchantManage> viewActiveMerchants();
	
	@Query(value="select * from capstore_merchants where merchant_status like 'inactive'",nativeQuery = true)
	public List<MerchantManage> viewInActiveMerchants();

}
