package com.cap.repo;





import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cap.entities.ProductManage;

@Repository
public interface ProductManageRepo extends JpaRepository<ProductManage, Long>{

//	@Query("FROM ProductManage as p where lower(p.productName) like lower(concat('%', ?1,'%'))")
//	List<ProductManage> getAllProductByProductName(String productName);
	

	

	
}


