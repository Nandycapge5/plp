package com.cap.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cap.entities.CustomerManage;
import com.cap.entities.MerchantManage;
import com.cap.entities.ProductManage;


@Service
public interface MerchantService {
	
//Merchant Operation
	//addMerchants
	public MerchantManage addMerchants(MerchantManage merchantManage);
	
	//deleteMerchants
	public void deleteMerchants(int id);
	
	//viewActiveMerchants
	public List<MerchantManage> viewActiveMerchants();
	
	//viewInActiveMerchants
	public List<MerchantManage> viewInActiveMerchants();
	
	//viewMerchantById
	public MerchantManage viewMerchantById(int id);
	
	//activeMerchants
	public MerchantManage activeMerchants(int id);
	
	
//product operations
	//view all products
	public List<ProductManage> viewAllProducts();
	
	//View product by id
	public ProductManage viewProductById(long productId);	
	
//Customer operations
	//view all customers
	public List<CustomerManage> viewAllCustomers();
	
	//View customer by id
	public CustomerManage viewCustomerById(long customerId);
	
	//view ActiveCustomer
	public List<CustomerManage> viewActiveCustomer();
	
	//view InActiveCustomer	
	public List<CustomerManage> viewInActiveCustomer();
	
	//active Customers
	public CustomerManage activeCustomers(long id);
	

	
	
	

}
