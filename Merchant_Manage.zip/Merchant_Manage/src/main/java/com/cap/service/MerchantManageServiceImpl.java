package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.entities.CustomerManage;
import com.cap.entities.MerchantManage;
import com.cap.entities.ProductManage;
import com.cap.repo.CustomerManageRepo;
import com.cap.repo.MerchantManageRepo;
import com.cap.repo.ProductManageRepo;

@Service
public class MerchantManageServiceImpl implements MerchantService{
	
	@Autowired
	MerchantManageRepo manageRepo;
	@Autowired
	ProductManageRepo productRepo;
	@Autowired 
	CustomerManageRepo customerRepo;
	

	@Override
	public MerchantManage addMerchants(MerchantManage merchantManage) {
		manageRepo.save(merchantManage);
		return merchantManage;
	}

	@Override
	public void deleteMerchants(int id) {
		manageRepo.deleteById(id);
				
	}


	@Override
	public MerchantManage viewMerchantById(int id) {
		MerchantManage merchantValue = manageRepo.findById(id).get();
		return merchantValue;
	}

	@Override
	public MerchantManage activeMerchants(int id) {
		MerchantManage merchantValue= manageRepo.findById(id).get();
		merchantValue.setMerchant_status("active");
	
	return manageRepo.save(merchantValue);
		
	}

	@Override
	public List<MerchantManage> viewActiveMerchants() {
		
		return manageRepo.viewActiveMerchants();
	}

	@Override
	public List<MerchantManage> viewInActiveMerchants() {
	
		return manageRepo.viewInActiveMerchants();
	}
	
	// Product Manage

	@Override
	public List<ProductManage> viewAllProducts() {
		
		return productRepo.findAll();
	}
	//ViewProductById
	@Override
	public ProductManage viewProductById(long productId) {
		
		 ProductManage productValue=productRepo.findById(productId).get();
		 return productValue;
	}
	
	
	// Customer Manage
	
	@Override
	public List<CustomerManage> viewAllCustomers() {
		
		return customerRepo.findAll();
	}
    //view CustomerById
	@Override
	public CustomerManage viewCustomerById(long customer_Id) {
		CustomerManage customerValue=customerRepo.findById(customer_Id).get();
		return customerValue;
	}

	@Override
	public List<CustomerManage> viewActiveCustomer() {
		
		return customerRepo.viewActiveCustomer();
	}

	@Override
	public List<CustomerManage> viewInActiveCustomer() {
		
		return customerRepo.viewInActiveCustomer();
	}

	@Override
	public CustomerManage activeCustomers(long id) {
		CustomerManage customerValue=customerRepo.findById(id).get();
		customerValue.setCustomer_Status("active");
		return customerRepo.save(customerValue);
	}
	
}
