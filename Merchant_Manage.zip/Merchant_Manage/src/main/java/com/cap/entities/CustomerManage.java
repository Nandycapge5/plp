package com.cap.entities;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.UniqueElements;

@Entity
@Table(name="capstore_customer")
public class CustomerManage {
	@Id
    @GeneratedValue
    @Column(length=20)
    private long customer_Id;
    
    @Column(length=20)
    @NotNull
    private String customer_Name;
    
    @Column(length=20)
    @NotNull
    private String customer_Password;
    
    @Column(length=20)
    @NotNull
    private String customer_ReEnterPassword;
    
    @Column(length=20)
    @NotNull
    private String customer_HomeAddress;
    
    @Column(length=20)
    @NotNull
    private String customer_ShippingAddress;
    
    @Column(length=20)
    @NotNull
    @UniqueElements
    private String customer_MobileNumber;
    
    @Column(length=20, unique=true)
    private String customer_Email;
    
    @Column(length=50)
    @NotNull
    private String customer_Question;
    
    @Column(length=20)
    @NotNull
    private String customer_Answer;
    
    @Column(length=10)
    @NotNull
    private String customer_Status="inactive";

	public long getCustomer_Id() {
		return customer_Id;
	}

	public void setCustomer_Id(long customer_Id) {
		this.customer_Id = customer_Id;
	}

	public String getCustomer_Name() {
		return customer_Name;
	}

	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}

	public String getCustomer_Password() {
		return customer_Password;
	}

	public void setCustomer_Password(String customer_Password) {
		this.customer_Password = customer_Password;
	}

	public String getCustomer_ReEnterPassword() {
		return customer_ReEnterPassword;
	}

	public void setCustomer_ReEnterPassword(String customer_ReEnterPassword) {
		this.customer_ReEnterPassword = customer_ReEnterPassword;
	}

	public String getCustomer_HomeAddress() {
		return customer_HomeAddress;
	}

	public void setCustomer_HomeAddress(String customer_HomeAddress) {
		this.customer_HomeAddress = customer_HomeAddress;
	}

	public String getCustomer_ShippingAddress() {
		return customer_ShippingAddress;
	}

	public void setCustomer_ShippingAddress(String customer_ShippingAddress) {
		this.customer_ShippingAddress = customer_ShippingAddress;
	}

	public String getCustomer_MobileNumber() {
		return customer_MobileNumber;
	}

	public void setCustomer_MobileNumber(String customer_MobileNumber) {
		this.customer_MobileNumber = customer_MobileNumber;
	}

	public String getCustomer_Email() {
		return customer_Email;
	}

	public void setCustomer_Email(String customer_Email) {
		this.customer_Email = customer_Email;
	}

	public String getCustomer_Question() {
		return customer_Question;
	}

	public void setCustomer_Question(String customer_Question) {
		this.customer_Question = customer_Question;
	}

	public String getCustomer_Answer() {
		return customer_Answer;
	}

	public void setCustomer_Answer(String customer_Answer) {
		this.customer_Answer = customer_Answer;
	}

	public String getCustomer_Status() {
		return customer_Status;
	}

	public void setCustomer_Status(String customer_Status) {
		this.customer_Status = customer_Status;
	}

	public CustomerManage(long customer_Id, @NotNull String customer_Name, @NotNull String customer_Password,
			@NotNull String customer_ReEnterPassword, @NotNull String customer_HomeAddress,
			@NotNull String customer_ShippingAddress, @NotNull @UniqueElements String customer_MobileNumber,
			String customer_Email, @NotNull String customer_Question, @NotNull String customer_Answer,@NotNull String customer_Status) {
		super();
		this.customer_Id = customer_Id;
		this.customer_Name = customer_Name;
		this.customer_Password = customer_Password;
		this.customer_ReEnterPassword = customer_ReEnterPassword;
		this.customer_HomeAddress = customer_HomeAddress;
		this.customer_ShippingAddress = customer_ShippingAddress;
		this.customer_MobileNumber = customer_MobileNumber;
		this.customer_Email = customer_Email;
		this.customer_Question = customer_Question;
		this.customer_Answer = customer_Answer;
		this.customer_Status=customer_Status;
	}

	public CustomerManage() {
		super();
	}
    
    

	

}
