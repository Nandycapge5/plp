import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.css']
})
export class ViewProductComponent implements OnInit {
  product:Product[]=[];
  service:ServiceService;
  column:string="productId";
  order:boolean=true;
  sort(column:string)
  {
    if(this.column==column)
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column
    }
  }
  constructor(service:ServiceService) { 

    this.service=service;
  }

  ngOnInit() {


    this.service.getProducts().subscribe(data1 => this.product = data1);

  }

}
