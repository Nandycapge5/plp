import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import { AdminMerchantManageComponent } from './admin-merchant-manage/admin-merchant-manage.component';
import { AdminUserValidationComponent } from './admin-user-validation/admin-user-validation.component';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';
import { ViewMerchantComponent } from './view-merchant/view-merchant.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { ViewProductComponent } from './view-product/view-product.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';

const routes: Routes=[
  //it will redirect thge page
  {
    path:'',
    component:AdminUserValidationComponent
  },
  {
    path:'Add Merchant',
    component:AddMerchantComponent
  },
  {
    path:'View Merchant',
    component:ViewMerchantComponent
  },
  {
    path:'Merchant Notification',
    component:AdminUserValidationComponent
  },
  {
    path:'Merchant Manage',
    component: AdminMerchantManageComponent
  },
  {
    path:'Delete Merchant',
    component: DeleteMerchantComponent
  },
  {
    path:'View Product',
    component: ViewProductComponent
  },
  {
    path:'View Customer',
    component:ViewCustomerComponent
  },
  {
    path:'Search Component',
    component:AdminMerchantManageComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
