import { Component, OnInit } from '@angular/core';
import {ServiceService } from '../service.service';
import { Merchant } from '../Merchant';

@Component({
  selector: 'app-view-merchant',
  templateUrl: './view-merchant.component.html',
  styleUrls: ['./view-merchant.component.css']
})
export class ViewMerchantComponent implements OnInit {

  service:ServiceService;
  column:string="merchantId";
  order:boolean=true;
  sort(column:string)
  {
    if(this.column==column)
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column
    }
  }
  
  constructor(service:ServiceService) {
    this.service=service;
   }
   merchants:Merchant[]=[]
   ngOnInit() {
    this.service.getActiveMerchants().subscribe(data => this.merchants = data);
  }
}
