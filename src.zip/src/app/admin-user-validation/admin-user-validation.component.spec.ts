import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUserValidationComponent } from './admin-user-validation.component';

describe('AdminUserValidationComponent', () => {
  let component: AdminUserValidationComponent;
  let fixture: ComponentFixture<AdminUserValidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUserValidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
