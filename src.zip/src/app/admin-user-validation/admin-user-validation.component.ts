import { Component, OnInit } from '@angular/core';
import { ServiceService} from '../service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Merchant } from '../Merchant';


@Component({
  selector: 'app-admin-user-validation',
  templateUrl: './admin-user-validation.component.html',
  styleUrls: ['./admin-user-validation.component.css']
})
export class AdminUserValidationComponent implements OnInit {
  routes:Router;
  status;
  merchants:Merchant[]=[];
  service:ServiceService;
  column:string="merchantId";
  order:boolean=true;
  sort(column:string)
  {
    if(this.column==column)
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column
    }
  }
  setIndex(ii){
    this.order=ii;
    console.log
  }
  constructor(service:ServiceService, routes:Router) {
    this.service=service;
    this.routes=routes;
   }
  
   ngOnInit() {
     //this.service.fetchMerchants();
     //this.merchants=this.service.getMerchants();
     this.service.getInactiveMerchants().subscribe(data => this.merchants = data);
     
  }

        // this.service.getMerchants()
        // .subscribe(merchants => { 
        //     this.merchants = merchants; 
           
        // });

  // delete(merchantId:String)
  // {
  //   this.service.delete(merchantId);
  // }
  
  // getMerchants() {
  //   this.merchants = this.service.getMerchants();
       
  //   }

 
  searchByID(merchantId1){
  this.service.searchByID(merchantId1).subscribe(data=>this.status=data);
}
  
  deleteMerchant(merchantId)
  {
    this.service.deleteMerchant(merchantId).subscribe(data=>this.status=data);
    window.alert("Deleted Successfully");

        
  }

  approve(merchantId:number)
  {
    //this.service.approve(merchantId);
    this.service.approve(merchantId).subscribe(data => this.status = data);
    window.alert("Approved Successfully");
  }
}






