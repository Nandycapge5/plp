import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMerchantManageComponent } from './admin-merchant-manage.component';

describe('AdminMerchantManageComponent', () => {
  let component: AdminMerchantManageComponent;
  let fixture: ComponentFixture<AdminMerchantManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMerchantManageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMerchantManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
