import { Component, OnInit } from '@angular/core';
import { ServiceService, } from '../service.service';
import { Merchant } from '../Merchant';
import { Router } from '@angular/router';
import { Observable, interval, Subscription } from 'rxjs';


@Component({
  selector: 'app-delete-merchant',
  templateUrl: './delete-merchant.component.html',
  styleUrls: ['./delete-merchant.component.css']
})
export class DeleteMerchantComponent implements OnInit {
 
  router:Router;
  service:ServiceService;
  column:string="merchantId";
  order:boolean=true;

  sort(column:string)
  {
    if(this.column==column)
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column
    }
  }
  constructor(service:ServiceService, router: Router) {
    this.service=service;
    this.router=router;
   }
   status;
   merchants:Merchant[]=[];
 
  private updateSubscription: Subscription;

  ngOnInit() {
    this.service.getActiveMerchants().subscribe(data => this.merchants = data);

           
      }


 
  deleteMerchant(merchantId)
  {
   
   this.service.deleteMerchant(merchantId).subscribe(data=>this.status=data);
   
  }
}
 