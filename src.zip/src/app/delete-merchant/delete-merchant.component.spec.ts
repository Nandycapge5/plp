import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteMerchantComponent } from './delete-merchant.component';

describe('DeleteMerchantComponent', () => {
  let component: DeleteMerchantComponent;
  let fixture: ComponentFixture<DeleteMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
