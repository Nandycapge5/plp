import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {
  
  customers:Customer[]=[];
  service:ServiceService;
  //customer_Name:"";
  column:string="customer_Name";
 order:boolean=true;
 sort(column:string)
 {
 if(this.column==column)
 {
 this.order=!this.order;
 }
 else{
 this.order=true;
 this.column=column;
 }
 }
  
  constructor(service:ServiceService) {
    this.service=service;
   }
   ngOnInit() {
    this.service.getCustomers().subscribe(data1 => this.customers = data1);
  }
}
