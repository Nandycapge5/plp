export class Merchant{
    merchantId:number;
    //merchantQue:string;
    //merchantAns:string;
    userName:string;
    email:string;
    password:string;
    companyName:string;
    mobNo:string;
    address:string;
    aadharNo:string;
    //merchant_status:string;
    
    
      
          constructor(merchantId:number,
            userName:string,email:string,password:string,address:string,companyName:string,mobNo:string,
           aadharNo:string)
            
          {
            this.merchantId=merchantId;
            //this.merchantQue=merchantQue;
            //this.merchantAns=merchantAns;
            this.userName=userName;
            this.email=email;
            this.password=password;
            this.address=address;
            this.companyName=companyName;
            this.mobNo=mobNo;
           
            this.aadharNo=aadharNo;
            //this.merchant_status=merchant_status;
          }
        }